#include <fmt/core.h>

int main() {
    fmt::print("Hello, {}!\n", "World");
    return 0;
}
